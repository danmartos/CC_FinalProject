﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class ShoppingCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable dt = new DataTable();
            DataRow dr;
            dt.Columns.Add("sno");
            dt.Columns.Add("Product ID");
            dt.Columns.Add("Category ID ");
            dt.Columns.Add("Product Description");
            dt.Columns.Add("Proudct Price");
            dt.Columns.Add("Cart Total");

            if (Request.QueryString["PROD_ID"] != null)
            {
                if (Session["Buyitems"] == null)
                {

                    dr = dt.NewRow();
                    String mycon = "Data Source=(localdb)ProjectsV13;AttachDbFilename=C:UsersTURKI M ALSHARARIDesktopCIS2918Classroom Connection 2018.mdf;Integrated Security=True";
                    SqlConnection scon = new SqlConnection(mycon);
                    String myquery = "select * from productdetail where Product ID=" + Request.QueryString["PROD_ID"];
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = myquery;
                    cmd.Connection = scon;
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    dr["sno"] = 1;
                    dr["Product ID"] = ds.Tables[0].Rows[0]["Product ID"].ToString();
                    dr["Category ID"] = ds.Tables[0].Rows[0]["Category ID"].ToString();
                    dr["Product Description"] = ds.Tables[0].Rows[0]["Product Description"].ToString();
                    dr["Proudct Price"] = ds.Tables[0].Rows[0]["Proudct Price"].ToString();
                    dt.Rows.Add(dr);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    Session["buyitems"] = dt;
                }
                else
                {

                    dt = (DataTable)Session["buyitems"];
                    int sr;
                    sr = dt.Rows.Count;

                    dr = dt.NewRow();
                    String mycon = "Data Source=Classroom Connection 2018.mdf;Initial Catalog=Classroom Connection 2018.mdf;Integrated Security=True";
                    SqlConnection scon = new SqlConnection(mycon);
                    String myquery = "select * from Product where Porduct ID=" + Request.QueryString["PROD_ID"];
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = myquery;
                    cmd.Connection = scon;
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    dr["sno"] = sr + 1;
                    dr["Product ID"] = ds.Tables[0].Rows[0]["Product ID"].ToString();
                    dr["Category ID"] = ds.Tables[0].Rows[0]["Category ID"].ToString();
                    dr["Product Description"] = ds.Tables[0].Rows[0]["Product Description"].ToString();
                    dr["Proudct Price"] = ds.Tables[0].Rows[0]["Proudct Price"].ToString();
                    dt.Rows.Add(dr);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                    Session["buyitems"] = dt;

                }
            }
            else
            {
                dt = (DataTable)Session["buyitems"];
                GridView1.DataSource = dt;
                GridView1.DataBind();

            }

        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}