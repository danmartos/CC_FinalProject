﻿CREATE TABLE [dbo].[Table]
(
	[UserID] INT NOT NULL PRIMARY KEY, 
    [AdminID] VARCHAR(50) NULL, 
    [Password] VARCHAR(250) NULL
)
