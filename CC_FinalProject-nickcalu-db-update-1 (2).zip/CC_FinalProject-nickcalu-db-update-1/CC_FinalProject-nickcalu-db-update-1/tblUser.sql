﻿CREATE TABLE [dbo].[Table]
(
	[UserID] INT NULL PRIMARY KEY, 
    [UserName] VARCHAR(50) NULL, 
    [Password] VARCHAR(250) NULL
)
